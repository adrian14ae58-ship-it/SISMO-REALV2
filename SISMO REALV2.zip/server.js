// ZETA SISMO — backend MVP (Node 18+). Fuente real: USGS. IGC: pendiente de endpoint oficial.
const http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const webpush = require('web-push');
const PORT = process.env.PORT || 3000;
const DATA = process.env.DATA_FILE || path.join(__dirname, 'data.json');
const TOKEN = process.env.ZETA_TOKEN || '';          // si se define, la API exige este token
const DEF = { lat: 8.98, lon: -79.52 };              // solo para simulaciones sin ubicación

let db = { events: [], alerts: [], subs: [], vapid: null, backfilled: false, seq: 0,
  settings: { loc: null, m: 4, r: 100, d: 70, push: true, usgs: true, igc: true },
  src: { usgs: { s: 'pending' }, igc: { s: 'pending' } } };
try { Object.assign(db, JSON.parse(fs.readFileSync(DATA, 'utf8'))); } catch {}
if (!db.vapid) db.vapid = webpush.generateVAPIDKeys();
webpush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:zeta@example.com', db.vapid.publicKey, db.vapid.privateKey);
const save = () => { try { fs.writeFileSync(DATA, JSON.stringify(db)); } catch (e) { console.error('save', e.message); } };

const R = Math.PI / 180;
const hav = (a, b, c, d) => { const x = Math.sin((c - a) * R / 2) ** 2 + Math.cos(a * R) * Math.cos(c * R) * Math.sin((d - b) * R / 2) ** 2; return 12742 * Math.asin(Math.sqrt(x)); };
const ref = e => db.settings.loc || (e.sim ? DEF : null);
const dist = e => { const p = ref(e); return p ? hav(p.lat, p.lon, e.lat, e.lon) : null; };
function level(m, d, p) {                              // magnitud + distancia + profundidad
  const s = db.settings;
  if (d == null || m < s.m || d > s.r || p > s.d) return 0;
  if (m >= 6 && d <= 60) return 3;
  if ((m >= 5 && d <= 100) || m >= 6) return 2;
  return 1;
}
const LV = ['INFORMACIÓN', 'AVISO', 'ALERTA', 'ALERTA CRÍTICA'];

async function push(e, a) {
  if (!db.settings.push) return;
  const d = a.d == null ? '' : `${a.d.toFixed(0)} km de tu ubicación · `;
  const body = JSON.stringify({ title: `${a.sim ? '⚠️ SIMULADO · ' : '🚨 '}ZETA SISMO · ${LV[a.l]}`,
    body: `M ${e.mag.toFixed(1)} · ${d}prof. ${e.dep} km · ${e.place}`, url: `/?event=${e.id}`, l: a.l });
  for (const s of [...db.subs]) {
    try { await webpush.sendNotification(s, body); }
    catch (x) { if (x.statusCode === 404 || x.statusCode === 410) db.subs = db.subs.filter(y => y.endpoint !== s.endpoint); }
  }
}

// Procesa un evento candidato: deduplica entre fuentes, guarda, calcula nivel y alerta.
async function ingest(c) {
  let e = db.events.find(x => x.refs.some(r => r.src === c.src && r.ext === c.ext));
  if (!e && !c.sim) e = db.events.find(x => !x.sim && Math.abs(x.t - c.t) < 60000 && hav(x.lat, x.lon, c.lat, c.lon) < 50 && Math.abs(x.mag - c.mag) < 0.7);
  if (e) {                                             // mismo evento: actualizar y asociar fuente
    if (!e.refs.some(r => r.src === c.src && r.ext === c.ext)) e.refs.push({ src: c.src, ext: c.ext });
    if (e.refs[0].src === c.src) Object.assign(e, { mag: c.mag, lat: c.lat, lon: c.lon, dep: c.dep, place: c.place, t: c.t });
    e.updated = Date.now(); return;
  }
  e = { id: `ZS-${new Date(c.t).getUTCFullYear()}-${String(++db.seq).padStart(5, '0')}`, mag: c.mag, lat: c.lat, lon: c.lon,
    dep: c.dep, t: c.t, place: c.place, refs: [{ src: c.src, ext: c.ext }], sim: !!c.sim, status: c.sim ? 'simulado' : 'automático', created: Date.now(), updated: Date.now() };
  db.events.push(e); db.events.sort((a, b) => b.t - a.t); db.events = db.events.slice(0, 3000);
  const fresh = c.sim || Date.now() - c.t < 3600e3;    // el histórico inicial no dispara alertas
  if (!fresh) return;
  const d = dist(e), l = level(e.mag, d, e.dep);
  if (l >= 1 || c.sim) { const a = { id: crypto.randomUUID(), eid: e.id, l, mag: e.mag, d, t: Date.now(), read: false, sim: e.sim }; db.alerts.unshift(a); db.alerts = db.alerts.slice(0, 300); await push(e, a); }
}

async function poll() {
  if (!db.settings.usgs) { db.src.usgs = { s: 'off' }; return save(); }
  try {
    const since = new Date(Date.now() - (db.backfilled ? 864e5 : 30 * 864e5)).toISOString();
    const u = `https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson&minlatitude=5.5&maxlatitude=10.5&minlongitude=-84&maxlongitude=-76&starttime=${since}&orderby=time-asc`;
    const r = await fetch(u); if (!r.ok) throw new Error('HTTP ' + r.status);
    const j = await r.json();
    for (const f of j.features) {
      if (f.properties.mag == null) continue;
      const [lon, lat, dep] = f.geometry.coordinates;
      await ingest({ src: 'USGS', ext: f.id, mag: f.properties.mag, lat, lon, dep: Math.round(dep), t: f.properties.time, place: f.properties.place || 'Panamá' });
    }
    db.backfilled = true; db.src.usgs = { s: 'ok', last: Date.now() };
  } catch (x) { db.src.usgs = { s: 'err', last: db.src.usgs.last, err: String(x.message) }; }
  // IGC: AQUÍ va la integración cuando se confirme el endpoint oficial (ver README). No se inventan datos.
  db.src.igc = { s: db.settings.igc ? 'pending' : 'off' };
  save();
}

const STATIC = new Set(['index.html','sw.js','manifest.webmanifest','icon-192.png','icon-512.png','apple-touch-icon.png','favicon.png']);
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml' };
const body = req => new Promise(ok => { let b = ''; req.on('data', c => b += c); req.on('end', () => { try { ok(JSON.parse(b || '{}')); } catch { ok({}); } }); });
const out = (res, c, o) => { res.writeHead(c, { 'content-type': 'application/json' }); res.end(JSON.stringify(o)); };

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname.startsWith('/api/')) {
    if (TOKEN && req.headers['x-token'] !== TOKEN) return out(res, 401, { error: 'token' });
    const p = url.pathname.slice(5);
    if (p === 'state') {
      const ev = db.events.slice(0, 600).map(e => { const d = dist(e); return { ...e, d, l: level(e.mag, d, e.dep) }; });
      return out(res, 200, { now: Date.now(), settings: db.settings, events: ev, alerts: db.alerts.slice(0, 100), src: db.src, vapid: db.vapid.publicKey, subs: db.subs.length });
    }
    const b = req.method === 'POST' ? await body(req) : {};
    if (p === 'settings') {
      const s = db.settings;
      if (b.loc && isFinite(b.loc.lat) && isFinite(b.loc.lon)) s.loc = { name: String(b.loc.name || 'Mi ubicación').slice(0, 40), lat: +b.loc.lat, lon: +b.loc.lon };
      for (const k of ['m', 'r', 'd']) if (isFinite(b[k])) s[k] = +b[k];
      for (const k of ['push', 'usgs', 'igc']) if (typeof b[k] === 'boolean') s[k] = b[k];
      save(); if (b.usgs) poll(); return out(res, 200, { ok: 1 });
    }
    if (p === 'subscribe' && b.sub && b.sub.endpoint) { db.subs = db.subs.filter(s => s.endpoint !== b.sub.endpoint); db.subs.push(b.sub); save(); return out(res, 200, { ok: 1 }); }
    if (p === 'alerts/read') { const a = db.alerts.find(x => x.id === b.id); if (a) a.read = true; save(); return out(res, 200, { ok: 1 }); }
    if (p === 'simulate') {
      const m = Math.min(7, Math.max(3, +b.m || 4)) + 0.4, o = ref({ sim: 1 }), km = [30, 40, 45, 35, 60][Math.floor(m) - 3], br = Math.random() * 6.283;
      await ingest({ src: 'SIMULADO', ext: 'sim-' + Date.now(), mag: m, lat: o.lat + km * Math.cos(br) / 111, lon: o.lon + km * Math.sin(br) / (111 * Math.cos(o.lat * R)),
        dep: Math.round(8 + Math.random() * 20), t: Date.now(), place: 'Panamá', sim: true });
      save(); return out(res, 200, { ok: 1 });
    }
    return out(res, 404, { error: 'no' });
  }
  const name = url.pathname === '/' ? 'index.html' : url.pathname.slice(1), f = path.join(__dirname, name);
  if (!STATIC.has(name) || !fs.existsSync(f)) { res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' }); return res.end('No encontrado: falta el archivo ' + name + '. Sube TODOS los archivos del proyecto a la misma carpeta de GitHub.'); }
  res.writeHead(200, { 'content-type': MIME[path.extname(f)] || 'application/octet-stream', 'cache-control': name === 'sw.js' || name === 'index.html' ? 'no-cache' : 'public, max-age=300' });
  fs.createReadStream(f).pipe(res);
}).listen(PORT, () => { console.log('ZETA SISMO en http://localhost:' + PORT + (TOKEN ? ' (con token)' : ' (SIN token: define ZETA_TOKEN al desplegar)')); poll(); setInterval(poll, 60000); });
