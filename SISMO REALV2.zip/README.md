# ZETA SISMO — MVP

Monitoreo sísmico personal de Panamá. PWA instalable en iPhone.
Fuente real: **USGS** (consulta cada 60 s). **IGC**: "Fuente pendiente de conexión" (ver `poll()` en `server.js`, donde va su endpoint oficial; no se inventa).

## 1) Verlo en tu computador (web)
Requiere Node 18+.
    npm install
    npm start
Abre http://localhost:3000

## 2) Instalarlo en tu iPhone (necesita HTTPS público)
Web Push en iPhone exige HTTPS y que la app esté instalada. Despliégalo en Render, Railway o Fly.io:
- Build: `npm install` — Start: `npm start`
- Variables de entorno:
  - `ZETA_TOKEN` = una clave larga tuya (protege la API y tu ubicación). **Obligatorio al publicar.**
  - `DATA_FILE` = ruta dentro de un disco persistente (ej. `/data/zeta.json`). Sin disco persistente se pierden eventos, ubicación y suscripciones al reiniciar.
  - `VAPID_SUBJECT` = `mailto:tucorreo@ejemplo.com`
En el iPhone (iOS 16.4 o superior):
1. Abre la URL en **Safari** e ingresa el token cuando lo pida.
2. Compartir → **Añadir a pantalla de inicio**. Abre la app desde ese icono.
3. Ajustes → guarda tu ubicación → **Activar notificaciones en este dispositivo**.
4. Prueba: Inicio → **SIMULAR M5**. Debe llegar el push; al tocarlo abre el evento en el mapa.

## Criterio de MVP terminado (8 pasos)
Sismo real en USGS → detectado → guardado → distancia → regla de alerta → push → abrir notificación → ver evento en el mapa.
El modo prueba recorre el mismo camino con "⚠️ EVENTO SIMULADO".

## Estructura
- `server.js` — monitor USGS, deduplicación entre fuentes, motor de alertas, Web Push, API, base JSON (`data.json`)
- Todos los archivos van JUNTOS en la misma carpeta, sin subcarpetas: server.js, package.json, index.html, sw.js, manifest.webmanifest y los 4 iconos PNG.
## Próximos pasos
Conectar IGC · PostgreSQL · réplicas/secuencias · estadísticas · autenticación completa · múltiples ubicaciones.
Aviso: no predice sismos ni garantiza avisar antes del movimiento fuerte.
